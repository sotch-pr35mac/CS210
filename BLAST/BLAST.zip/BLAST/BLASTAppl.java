/*
* @author: Preston Stosur-Bassett
* @date: 25.11.14
* @course: CS210
* @class: BLASTAppl
* @description: This class contains the main method which creates and runs the simulation.
*/

public class BLASTAppl {
  public static void main(String[] args) {
    //Run the simulation
    Simulation sim = new Simulation();
    sim.runner();
  }
}
